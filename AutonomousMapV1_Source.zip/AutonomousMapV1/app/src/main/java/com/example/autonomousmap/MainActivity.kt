package com.example.autonomousmap

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var mapView: MapCanvasView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "自主地图"
        mapView = MapCanvasView(this)
        status = TextView(this).apply {
            text = "模式：移动地图  |  中心点：未设置"
            textSize = 13f
            setPadding(10, 8, 10, 8)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF3F5F7.toInt())
        }
        val toolbar1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val toolbar2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
            parent.addView(Button(this).apply {
                text = label
                isAllCaps = false
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(0, 48, 1f))
        }

        addButton(toolbar1, "移动") {
            mapView.setDrawMode(false)
            updateStatus()
        }
        addButton(toolbar1, "绘制") {
            mapView.setDrawMode(true)
            updateStatus()
        }
        addButton(toolbar1, "设置中心坐标") { showCenterDialog() }

        addButton(toolbar2, "保存地图") {
            try {
                mapView.saveToFile()
                Toast.makeText(this, "地图已保存在手机本地", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "保存失败：${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        addButton(toolbar2, "打开地图") {
            try {
                val loaded = mapView.loadFromFile()
                Toast.makeText(this, if (loaded) "已读取本地地图" else "还没有保存过地图", Toast.LENGTH_SHORT).show()
                updateStatus()
            } catch (e: Exception) {
                Toast.makeText(this, "读取失败：${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        addButton(toolbar2, "撤销") { mapView.undo() }

        root.addView(status)
        root.addView(toolbar1)
        root.addView(toolbar2)
        root.addView(mapView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
    }

    private fun updateStatus() {
        val mode = if (mapView.isDrawMode()) "绘制" else "移动地图"
        status.text = "模式：$mode  |  中心点：${mapView.centerLatitude}, ${mapView.centerLongitude}"
    }

    private fun showCenterDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
        }
        val lat = EditText(this).apply {
            hint = "纬度，例如 32.0415"
            inputType = 8194
            setText(mapView.centerLatitude)
        }
        val lon = EditText(this).apply {
            hint = "经度，例如 118. tan"
            inputType = 8194
            setText(mapView.centerLongitude)
        }
        box.addView(lat)
        box.addView(lon)
        AlertDialog.Builder(this)
            .setTitle("设置地图中心经纬度")
            .setMessage("请输入真实地理坐标。纬度范围 -90 到 90，经度范围 -180 到 180。")
            .setView(box)
            .setNegativeButton("取消", null)
            .setPositiveButton("确定") { _, _ ->
                val a = lat.text.toString().trim().toDoubleOrNull()
                val b = lon.text.toString().trim().toDoubleOrNull()
                if (a == null || b == null || a !in -90.0..90.0 || b !in -180.0..180.0) {
                    Toast.makeText(this, "坐标格式不正确", Toast.LENGTH_LONG).show()
                } else {
                    mapView.setCenter(a, b)
                    updateStatus()
                }
            }.show()
    }
}
