package com.example.autonomousmap

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.max
import kotlin.math.min

class MapCanvasView(context: Context) : View(context) {
    private data class Stroke(val points: MutableList<Pair<Float, Float>>)

    private val strokes = mutableListOf<Stroke>()
    private var currentStroke: Stroke? = null
    private var drawMode = false
    private var offsetX = 0f
    private var offsetY = 0f
    private var zoom = 1f
    var centerLatitude = ""
        private set
    var centerLongitude = ""
        private set

    private val backgroundPaint = Paint().apply { color = Color.rgb(250, 250, 248) }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(225, 229, 232)
        strokeWidth = 1f
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(25, 105, 190)
        strokeWidth = 5f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.DKGRAY
        textSize = 34f
    }

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                zoom = (zoom * detector.scaleFactor).coerceIn(0.25f, 8f)
                invalidate()
                return true
            }
        })

    private var lastX = 0f
    private var lastY = 0f

    fun setDrawMode(enabled: Boolean) {
        drawMode = enabled
        invalidate()
    }
    fun isDrawMode() = drawMode

    fun setCenter(lat: Double, lon: Double) {
        centerLatitude = lat.toString()
        centerLongitude = lon.toString()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), backgroundPaint)
        canvas.save()
        canvas.translate(width / 2f + offsetX, height / 2f + offsetY)
        canvas.scale(zoom, zoom)

        val spacing = 80f
        val left = -width.toFloat()
        val right = width.toFloat()
        val top = -height.toFloat()
        val bottom = height.toFloat()
        var x = left
        while (x <= right) {
            canvas.drawLine(x, top, x, bottom, gridPaint)
            x += spacing
        }
        var y = top
        while (y <= bottom) {
            canvas.drawLine(left, y, right, y, gridPaint)
            y += spacing
        }

        for (stroke in strokes) drawStroke(canvas, stroke)
        currentStroke?.let { drawStroke(canvas, it) }
        canvas.restore()

        val hint = if (drawMode) "绘制模式：手指在画布上滑动即可画线" else "移动模式：单指拖动，双指缩放"
        canvas.drawText(hint, 20f, height - 28f, hintPaint)
    }

    private fun drawStroke(canvas: Canvas, stroke: Stroke) {
        if (stroke.points.size < 2) return
        val path = Path()
        path.moveTo(stroke.points[0].first, stroke.points[0].second)
        for (i in 1 until stroke.points.size) {
            path.lineTo(stroke.points[i].first, stroke.points[i].second)
        }
        canvas.drawPath(path, linePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                if (drawMode) {
                    val p = screenToWorld(event.x, event.y)
                    currentStroke = Stroke(mutableListOf(p))
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                currentStroke = null
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2) return true
                val dx = event.x - lastX
                val dy = event.y - lastY
                if (drawMode) {
                    currentStroke?.points?.add(screenToWorld(event.x, event.y))
                } else {
                    offsetX += dx
                    offsetY += dy
                }
                lastX = event.x
                lastY = event.y
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                currentStroke?.let {
                    if (it.points.isNotEmpty()) strokes.add(it)
                }
                currentStroke = null
                invalidate()
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                currentStroke = null
                invalidate()
                return true
            }
        }
        return true
    }

    private fun screenToWorld(x: Float, y: Float): Pair<Float, Float> {
        return Pair((x - width / 2f - offsetX) / zoom, (y - height / 2f - offsetY) / zoom)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    fun undo() {
        if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex)
        invalidate()
    }

    fun saveToFile() {
        val root = JSONObject()
        root.put("centerLatitude", centerLatitude)
        root.put("centerLongitude", centerLongitude)
        root.put("zoom", zoom.toDouble())
        root.put("offsetX", offsetX.toDouble())
        root.put("offsetY", offsetY.toDouble())
        val all = JSONArray()
        for (stroke in strokes) {
            val points = JSONArray()
            for (p in stroke.points) {
                points.put(JSONArray().put(p.first.toDouble()).put(p.second.toDouble()))
            }
            all.put(points)
        }
        root.put("strokes", all)
        File(context.filesDir, "my_map.json").writeText(root.toString())
    }

    fun loadFromFile(): Boolean {
        val file = File(context.filesDir, "my_map.json")
        if (!file.exists()) return false
        val root = JSONObject(file.readText())
        centerLatitude = root.optString("centerLatitude", "")
        centerLongitude = root.optString("centerLongitude", "")
        zoom = root.optDouble("zoom", 1.0).toFloat().coerceIn(0.25f, 8f)
        offsetX = root.optDouble("offsetX", 0.0).toFloat()
        offsetY = root.optDouble("offsetY", 0.0).toFloat()
        strokes.clear()
        val all = root.optJSONArray("strokes") ?: JSONArray()
        for (i in 0 until all.length()) {
            val pointsJson = all.getJSONArray(i)
            val points = mutableListOf<Pair<Float, Float>>()
            for (j in 0 until pointsJson.length()) {
                val p = pointsJson.getJSONArray(j)
                points.add(Pair(p.getDouble(0).toFloat(), p.getDouble(1).toFloat()))
            }
            strokes.add(Stroke(points))
        }
        invalidate()
        return true
    }
}
