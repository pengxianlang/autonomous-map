# 自主地图 Android 第一阶段

这是一个不依赖第三方地图 SDK 的原生 Android Kotlin 项目。

## 当前功能
- 空白网格画布
- 单指移动画布
- 双指缩放
- 绘制模式下手指自由画线
- 撤销最后一条线
- 设置真实经纬度中心点（目前作为地图元数据保存）
- 保存/读取本地地图 JSON 文件

## 手机 GitHub 编译
1. 将本项目所有文件上传到 GitHub 仓库根目录。
2. 确认 `.github/workflows/build.yml` 也已上传。
3. 打开仓库的 Actions 页面。
4. 选择 `Build Autonomous Map APK`，点击 `Run workflow`；也可以上传文件后等待 push 自动触发。
5. 打开成功的运行记录，在 Artifacts 下载 `autonomous-map-debug-apk`。
6. 解压后安装 `app-debug.apk`。

## 说明
- 这是第一阶段画布原型，不是完整导航地图。
- 目前绘图笔迹使用画布局部坐标；设置的经纬度中心点作为元数据保存，尚未将每条笔迹转换为地理坐标。
- 后续阶段会把画布坐标映射到真实地理坐标，再加入 GPS、地图对象和路线规划。
- 需要 Android Gradle Plugin 8.7.3、Gradle 8.9、JDK 17；GitHub Actions 工作流已配置。
